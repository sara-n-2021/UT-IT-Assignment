package com.knoldus.models

case class Company(name: String,
                   emailId: String,
                   city: String)
