package com.knoldus.models

case class Employee(firstName: String,
                    lastName: String,
                    age: Int,
                    salary: Double,
                    designation: String,
                    companyName: String,
                    emailId: String)
