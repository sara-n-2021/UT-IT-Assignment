package com.knoldus.validator

class EmailValidator {

  def emailIdIsValid(emailId: String): Boolean = ???
}
